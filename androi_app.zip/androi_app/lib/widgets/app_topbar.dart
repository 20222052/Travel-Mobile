import 'package:flutter/material.dart';
import 'package:provider/provider.dart';                 // ✅ thêm
import 'package:badges/badges.dart' as badges;           // ✅ thêm
import '../config/api_config.dart';
import '../state/cart_state.dart';                       // ✅ thêm

class AppTopBar extends StatelessWidget implements PreferredSizeWidget {
  final TextEditingController searchCtrl;
  final VoidCallback? onCart;
  final ValueChanged<String>? onSearchSubmitted;

  final String currentSort; // 'desc' | 'asc'
  final ValueChanged<String>? onSortChanged;

  final String hintText;

  const AppTopBar({
    super.key,
    required this.searchCtrl,
    this.onCart,
    this.onSearchSubmitted,
    this.currentSort = 'desc',
    this.onSortChanged,
    this.hintText = 'Tìm tour…',
  });

  @override
  Size get preferredSize => const Size.fromHeight(64);

  static String get _logoUrl => '${ApiConfig.baseUrl}/img/logo.png';

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      bottom: false,
      child: Container(
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface,
          border: const Border(bottom: BorderSide(color: Color(0x11000000))),
        ),
        child: Row(
          children: [
            SizedBox(
              width: 36, height: 36,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.network(
                  _logoUrl, fit: BoxFit.contain,
                  errorBuilder: (_, __, ___) => Container(
                    color: Colors.blue.shade50, alignment: Alignment.center,
                    child: const Icon(Icons.image, color: Colors.grey, size: 22),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 10),

            Expanded(
              child: SizedBox(
                height: 40,
                child: TextField(
                  controller: searchCtrl,
                  textInputAction: TextInputAction.search,
                  onSubmitted: onSearchSubmitted,
                  decoration: InputDecoration(
                    hintText: hintText,
                    prefixIcon: const Icon(Icons.search),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 12),
                    filled: true,
                    fillColor: Colors.grey.shade100,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
              ),
            ),

            const SizedBox(width: 8),

            SizedBox(
              height: 40,
              child: DropdownButtonHideUnderline(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade100,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.black12),
                  ),
                  child: DropdownButton<String>(
                    value: currentSort,
                    onChanged: (val) { if (val != null) onSortChanged?.call(val); },
                    items: const [
                      DropdownMenuItem(value: 'desc', child: Text('Mới nhất')),
                      DropdownMenuItem(value: 'asc',  child: Text('Cũ nhất')),
                    ],
                  ),
                ),
              ),
            ),

            const SizedBox(width: 8),

            // ✅ Icon giỏ hàng có badge số lượng
            Consumer<CartState>(
              builder: (_, cart, __) => IconButton(
                onPressed: onCart,
                icon: badges.Badge(
                  badgeContent: Text(
                    '${cart.totalCount}',
                    style: const TextStyle(color: Colors.white, fontSize: 10),
                  ),
                  showBadge: cart.totalCount > 0,
                  position: badges.BadgePosition.topEnd(top: -4, end: -4),
                  child: const Icon(Icons.shopping_cart_outlined, size: 26),
                ),
                tooltip: 'Giỏ hàng',
              ),
            ),
          ],
        ),
      ),
    );
  }
}
