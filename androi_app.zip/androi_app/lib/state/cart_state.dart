import 'package:flutter/foundation.dart';

class CartItemLite {
  final int id;
  final String name;
  final double price;
  int qty;
  CartItemLite({required this.id, required this.name, required this.price, this.qty = 1});
}

class CartState extends ChangeNotifier {
  final Map<int, CartItemLite> _items = {}; // key = productId

  int get totalCount => _items.values.fold(0, (s, e) => s + e.qty);

  void add(CartItemLite item, {int qty = 1}) {
    final ex = _items[item.id];
    if (ex == null) {
      _items[item.id] = CartItemLite(id: item.id, name: item.name, price: item.price, qty: qty);
    } else {
      ex.qty += qty;                        // ✅ đã có → tăng số lượng
    }
    notifyListeners();
  }

  void changeQty(int id, int delta) {
    final it = _items[id];
    if (it == null) return;
    it.qty = (it.qty + delta).clamp(1, 9999);
    notifyListeners();
  }

  void remove(int id) { _items.remove(id); notifyListeners(); }
  void clear() { _items.clear(); notifyListeners(); }
}
